var express = require('express');
var todoController = require('./controllers/indexC');

var app = express();

//sets up template
app.set('view engine', 'ejs');

//static file
app.use(express.static('./public'));

//fire controllers
todoController(app);

//listen to port
app.listen(3000);
console.log('Listening to port 3000');